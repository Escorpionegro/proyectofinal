//escenarios
const scene = new THREE.Scene();
//scene.background = new THREE.Color(0xBCFBEF);
scene.fog = new THREE.Fog(0xF85D79, 0.9, 9);

var loader  = new  THREE.TextureLoader();
loader.load(
'../imagenes/yei.jpg', function  (texture) {
scene.background = texture
}
);

//camara
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );





//render
const renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
document.body.appendChild( renderer.domElement );

//geometrias
const length = 1, width = 2;

const shape = new THREE.Shape();
shape.moveTo( 0,0 );
shape.lineTo( 0, width );
shape.lineTo( length, width );
shape.lineTo( length, 0 );
shape.lineTo( 0, 0 );

const extrudeSettings = {
	steps: 1,
	depth: 0.1,
	bevelEnabled: true,
	bevelThickness: 0.5,
	bevelSize: 1,
	bevelOffset: 0,
	bevelSegments: 1
};

const geometry = new THREE.ExtrudeGeometry( shape, extrudeSettings );
const material = new THREE.MeshBasicMaterial( { color: 0xffffff } );
const mesh = new THREE.Mesh( geometry, material ) ;
scene.add( mesh );



camera.position.z = 5;

//animacion
function animate() {
	requestAnimationFrame( animate );
    mesh.rotation.x += 0.01;
mesh.rotation.y += 0.01;
mesh.rotation.z+= 0.01

	renderer.render( scene, camera );
}
animate();
