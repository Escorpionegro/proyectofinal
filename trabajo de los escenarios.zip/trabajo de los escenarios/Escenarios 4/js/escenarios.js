//escenarios
const scene = new THREE.Scene();



var loader  = new  THREE.TextureLoader();
loader.load(
'../imagenes/ja.jpg', function  (texture) {
scene.background = texture
}
);

//camara
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );





//render
const renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );	
document.body.appendChild( renderer.domElement );

//geometrias
const geometry = new THREE.CylinderGeometry( 5, 5, 20, 32 );
const material = new THREE.MeshBasicMaterial( {color: 0xC8A874} );
const cylinder = new THREE.Mesh( geometry, material );
scene.add( cylinder );

camera.position.z = 20;

//animacion
function animate() {
	requestAnimationFrame( animate );
    cylinder.rotation.x += 0.03;
cylinder.rotation.y += 0.05;
	cylinder.rotation.z += 0.06;

	renderer.render( scene, camera );
}
animate();
